export interface QrCodeType {
  type: 'url' | 'wifi';
  data: string;
  color: string;
  bgColor: string;
}