import React from 'react';
import { QrCode } from 'lucide-react';
import Header from './components/Header';
import QRCodeGenerator from './components/QRCodeGenerator';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-4xl">
          <QRCodeGenerator />
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;